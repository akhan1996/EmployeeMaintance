"use strict";
var Book = (function () {
    function Book(id, title, year, author) {
        this.id = id;
        this.title = title;
        this.year = year;
        this.author = author;
    }
    Book.prototype.setId = function (id) {
        this.id = id;
    };
    Book.prototype.setTitle = function (title) {
        this.title = title;
    };
    Book.prototype.setYear = function (year) {
        this.year = year;
    };
    Book.prototype.setAuthor = function (author) {
        this.author = author;
    };
    Book.prototype.getId = function () {
        return this.id;
    };
    Book.prototype.getTitle = function () {
        return this.title;
    };
    Book.prototype.getYear = function () {
        return this.year;
    };
    Book.prototype.getAuthor = function () {
        return this.author;
    };
    return Book;
}());
exports.Book = Book;
//# sourceMappingURL=Book.js.map