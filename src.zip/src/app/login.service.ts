import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Book} from './Book'
import 'rxjs/Rx';

@Injectable()
export class yourService {
	data:Array<Object>;
	books=new Array();
    constructor(public http:Http) {
	this.http.get('booklist.json')
                .subscribe(res => this.data = res.json());
	}
	
	public getBook(){
	if(this.books.length==this.data.length){
		return this.books;
	}
		for(let i=0;i<this.data.length;i++){
		let book = new Book();
		book.setId(this.data[i]['id']);
		book.setTitle(this.data[i]['title']);
		book.setYear(this.data[i]['year']);
		book.setAuthor(this.data[i]['author']);
		this.books.push(book);
	}
		return this.books;
}
}