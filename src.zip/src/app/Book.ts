export class Book{
id:number;
title:string;
year:number
author:string;
constructor(id:number,title:string,year:number,author:string) {
        this.id=id;
        this.title=title;
        this.year=year;
		this.author=author;
    }
public setId(id:number){
		this.id = id;
	}
	public setTitle(title:string){
		this.title = title;
	}
	public setYear(year:number){
		this.year = year;
	}
	public setAuthor(author:string){
		this.author = author;
	}
	
	public getId(){
		return this.id;
	}
	public getTitle(){
		return this.title;
	}
	public getYear(){
		return this.year;
	}
	public getAuthor(){
		return this.author;
	}
} 
 


