import { Component } from '@angular/core';
import { Book } from './book';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'Practice';
  index = -1;
  uid;
  utitle;
  uyear;
  uauthor;
  book = new Book("",0,"","");
  arrBooks = new Array();
  
  constructor(private http: HttpClient) {
		this.getJSON().subscribe(data => {
			for(let book of data){
				this.arrBooks.push(book);
				console.log(book);
			}
		});
	}


	public getJSON(): Observable<any> {
		return this.http.get("./assets/booklist.json")
	}
	deleteBook(book:Book){
    let ind=this.arrBooks.indexOf(book);
    console.log("ind");
    this.arrBooks.splice(ind,1);
  //  this.message="DATA DELETED"
  }
  
  update(book:Book){
  this.index=this.arrBooks.indexOf(book);
  this.uid=book.id;
  this.utitle = book.title;
  this.uyear = book.year;
  this.uauthor = book.author;
}
updateBook(){
    this.book.id = this.uid;
    this.book.title = this.utitle;
    this.book.year = this.uyear;
    this.book.author = this.uauthor;

 this.arrBooks[this.index] = this.book;
   // this.message = "DATA updated";

    this.uid = "";
    this.utitle = "";
    this.uyear = "";
    this.uauthor = "";

  }
}
