export class Book{
id;
title;
year;
author;
 
   constructor(id,title,year,author)
   {
    this.id=id;
    this.title=title;
    this.title=title;
    this.author=author;
  }
}

