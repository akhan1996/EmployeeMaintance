export class College{
collegeId:number;
collegeName:string;

state:string;
constructor(collegeId:number,collegeName:string,state:string) {
        this.collegeId=collegeId;
        this.collegeName=collegeName;
		this.state=state;
    }
public setcollegeId(collegeId:number){
		this.collegeId = collegeId;
	}
	public setcollegeName(collegeName:string){
		this.collegeName = collegeName;
	}

	public setState(state:string){
		this.state = state;
	}
	
	public getcollegeId(){
		return this.collegeId;
	}
	public getcollegeName(){
		return this.collegeName;
	}
	public getState(){
		return this.state;
	}
} 