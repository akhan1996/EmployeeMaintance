import { Component } from '@angular/core';
import {Http} from '@angular/http';
import { Observable } from "rxjs"
import {collegeService} from './college.service';
import {College} from './College'

@Component({
  selector: 'my-app',
   templateUrl: './app.component.html',
})

export class AppComponent { 

name = 'Welcome Json';
collegeId:number;
collegeName:string;
state:string;
clg = new Array();
constructor(private newService: collegeService) {} 
	
	public invokeMethod(){
	this.clg=this.newService.getCollege();
	}
	
	public delete(college:College){
    let ind=this.clg.indexOf(college);
	console.log(college);
    this.clg.splice(ind,1);
}

  public sortId(){
  this.clg=this.clg.sort((a:College,b:College) => a.collegeId - b.collegeId);
  } 
  
  public sortName(event:Event){
  this.clg=this.clg.sort((a:College,b:College) => a.getcollegeName().localeCompare(b.getcollegeName()));
  }
  
  public sortState(event:Event){
  this.clg=this.clg.sort((a:College,b:College) => a.getState().localeCompare(b.getState()));
  }
} 

