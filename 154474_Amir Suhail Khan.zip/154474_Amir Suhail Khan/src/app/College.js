"use strict";
var College = (function () {
    function College(collegeId, collegeName, state) {
        this.collegeId = collegeId;
        this.collegeName = collegeName;
        this.state = state;
    }
    College.prototype.setcollegeId = function (collegeId) {
        this.collegeId = collegeId;
    };
    College.prototype.setcollegeName = function (collegeName) {
        this.collegeName = collegeName;
    };
    College.prototype.setState = function (state) {
        this.state = state;
    };
    College.prototype.getcollegeId = function () {
        return this.collegeId;
    };
    College.prototype.getcollegeName = function () {
        return this.collegeName;
    };
    College.prototype.getState = function () {
        return this.state;
    };
    return College;
}());
exports.College = College;
//# sourceMappingURL=College.js.map