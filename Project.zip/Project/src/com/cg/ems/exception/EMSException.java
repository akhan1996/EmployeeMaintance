package com.cg.ems.exception;

public class EMSException extends Exception {
	private static final long serialVersionUID = 726264577455921591L;

	public EMSException(String message) {
		super(message);
	}

}
