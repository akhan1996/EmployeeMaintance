package com.igate.donorapplication.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.igate.donorapplication.bean.DonorBean;
import com.igate.donorapplication.dao.DonorDaoImpl;
import com.igate.donorapplication.dao.IDonorDAO;
import com.igate.donorapplication.exception.DonorException;

public class DonorServiceImpl implements IDonorService {
	
	IDonorDAO donorDao;
	
	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addDonorDetails
	 - Input Parameters	:	donor object
	 - Return Type		:	String id
	 - Throws			:  	DonorException
	 - Author			:	IGATE
	 - Creation Date	:	09/11/2014
	 - Description		:	adding donor to database calls dao method addDonorDetails(donor)
	 ********************************************************************************************************/
	public String addDonorDetails(DonorBean donor) throws DonorException {
		donorDao=new DonorDaoImpl();	
		String donorSeq;
		donorSeq= donorDao.addDonorDetails(donor);
		return donorSeq; 
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewDonorDetails
	 - Input Parameters	:	String donorId
	 - Return Type		:	donor object
	 - Throws		    :  	DonorException
	 - Author		    :	IGATE
	 - Creation Date	:	09/11/2014
	 - Description		:	calls dao method viewDonorDetails(donorId)
	 ********************************************************************************************************/
	public DonorBean viewDonorDetails(String donorId) throws DonorException {
		donorDao=new DonorDaoImpl();
		DonorBean bean=null;
		bean=donorDao.viewDonorDetails(donorId);
		return bean;
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : DonorException
	 - Author	      	: IGATE	 
	 - Creation Date	: 09/11/2014
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	public List<DonorBean> retriveAll() throws DonorException {
		donorDao=new DonorDaoImpl();
		List<DonorBean> donorList=null;
		donorList=donorDao.retriveAllDetails();
		return donorList;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	: validateDonor(DonorBean bean)
	 - Input Parameters	: DonorBean bean
	 - Return Type		: void
	 - Throws		    : DonorException
	 - Author	      	: IGATE	 
	 - Creation Date	: 09/11/2014
	 - Description		: validates the DonorBean object
	 * @return 
	 ********************************************************************************************************/
	public void validateDonor(DonorBean bean) throws DonorException
	{
		String errorMessage = "";
		String donorName  = null;
		String address    = null;
		String phoneNumber= null;
		double amount      = 0.0d;
		
		//Validating donor name
		donorName=bean.getDonorName();
		
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		
		if(!(nameMatcher.matches()))
		{
			errorMessage+="\nDonar Name Should Be In Alphabets and minimum 3 characters long.";
			
		}
		
		//Validating address
		address=bean.getAddress();
		if( address.length() < 6)
		{
			errorMessage+="\nAddress Should Be Greater Than 5 Characters";
			
		}
		
		//Validating Phone Number
		phoneNumber=bean.getPhoneNumber();
		
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		
		if(!(phoneMatcher.matches()))
		{
			errorMessage+="\nPhone Number Should be in 10 digit";
			
		}
		
		
		//Validating Donation Amount
		amount = bean.getDonationAmount();
		
		if(amount<0)
		{
			errorMessage+="\nAmount Should be a positive Number.";
			
		}
		
		if(!errorMessage.isEmpty())
			throw new DonorException(errorMessage);
	}

	public boolean validateDonorId(String donorId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(donorId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}

	
	


