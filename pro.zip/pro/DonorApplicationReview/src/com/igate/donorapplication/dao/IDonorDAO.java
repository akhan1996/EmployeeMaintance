package com.igate.donorapplication.dao;

import java.util.List;

import com.igate.donorapplication.bean.DonorBean;
import com.igate.donorapplication.exception.DonorException;

public interface IDonorDAO 
{
	public String addDonorDetails(DonorBean donor) throws DonorException;
	public DonorBean viewDonorDetails(String donorId) throws DonorException;
	public List<DonorBean> retriveAllDetails()throws DonorException;
}
