package com.cg.student.service;

import com.cg.student.bean.Login;

public class StudentImpl implements IStudent {

	public boolean isValid(Login log){
		
		String name = log.getUserName();
		String pass= log.getPassword();
		if(name.length() > 4 && pass.length() > 4){
			System.out.println("Valid User!");
			if(name.equals("aamir") && pass.equals("aamir123")){
				System.out.println("Correct creditantials");
				return true;
			}else{
					System.out.println("Incorrect credentials");
					return false;
			}
		}
		else{
			System.out.println("Invalid User!");
		return false;
		}
	}
	
	
}
