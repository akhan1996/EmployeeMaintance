package com.cg.student.service;

import com.cg.student.bean.Login;

public interface IStudent {
	
	public boolean isValid(Login log);

}
