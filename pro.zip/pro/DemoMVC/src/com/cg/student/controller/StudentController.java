package com.cg.student.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



import javax.validation.Valid;


//import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.student.bean.Login;
import com.cg.student.bean.Student;
import com.cg.student.service.IStudent;
import com.cg.student.service.StudentImpl;
//@Scope("session")
@Controller
@RequestMapping(value="user")
public class StudentController {

		ArrayList<String> cityList;
		ArrayList<String> courseList;
		Map<String, Object> map;
		@RequestMapping(value="/show")
		public String prepareLogin(Model model)
		{
			System.out.println("In prepareLogin() method");
			model.addAttribute("login",new Login());
			return "login";
		}
		
		@RequestMapping(value="/checkLogin")
		public ModelAndView checkLogin(@ModelAttribute("login") @Valid Login log, BindingResult bindingResult)
		{
			if(!bindingResult.hasErrors()){
		map= new HashMap<>();
		map.put("username", log.getUserName());
		map.put("password", log.getPassword());
		IStudent stu = new StudentImpl();
		Login l = new Login();
		l.setUserName(log.getUserName());
		l.setPassword(log.getPassword());
//		if(stu.isValid(l)){
cityList =new ArrayList<String>();
			
			cityList.add("Mumbai");
			cityList.add("Bangalore");
			cityList.add("Chennai");
			cityList.add("Delhi");
			
			courseList =new ArrayList<String>();
			
			courseList.add("Java");
			courseList.add("Struts");
			courseList.add("Spring");
			courseList.add("Hibernate");
			
			map.put("cityList", cityList);
			map.put("courseList", courseList);
			map.put("student", new Student());
//			model.addAttribute("cityList",cityList);
//			model.addAttribute("courseList",courseList);

//			model.addAttribute("student",new Student());
			return new ModelAndView("register",map);
		}else{
//		  	return new ModelAndView("loginSuccess","username",log.getUserName());	
		return new ModelAndView("error");
		}
			
		}

//		@RequestMapping(value="/showRegister")
//		public String prepareRegister(Model model)
//		{
//			cityList =new ArrayList<String>();
//			
//			cityList.add("Mumbai");
//			cityList.add("Bangalore");
//			cityList.add("Chennai");
//			cityList.add("Delhi");
//			
//			courseList =new ArrayList<String>();
//			
//			courseList.add("Java");
//			courseList.add("Struts");
//			courseList.add("Spring");
//			courseList.add("Hibernate");
//			
//			model.addAttribute("cityList",cityList);
//			model.addAttribute("courseList",courseList);
//			
//			model.addAttribute("student",new Student());
//		    return "register";	
//		}
//		
		@RequestMapping(value="/checkRegister")
		public String checkRegister(@ModelAttribute("student") Student student ,Model model)
		{
	          model.addAttribute("student",student);  		  
		  	  return "registerSuccess";	
		}
//		 Click Here to <a href="student/showRegister.obj">Register</a><br/>
		
}

