package com.cg.student.bean;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



public class Login implements Serializable{
	
	@NotEmpty(message=" Enter some data")
	@Size(min=2 ,max=6 ,message="length must be in b/w 4 and 8")
	private String userName;
	@NotEmpty(message="Enter password")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
