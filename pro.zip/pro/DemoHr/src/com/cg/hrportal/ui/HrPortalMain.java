package com.cg.hrportal.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.hrportal.exception.HrPortalException;
import com.cg.hrportal.service.HrPortalService;
import com.cg.hrportal.service.HrValidater;
import com.cg.hrportal.service.IHRMan;
import com.cg.hrportal.service.IHRRec;
import com.cg.hrportal.service.IHRSrMan;

public class HrPortalMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("----------Welcome---------\n");
		System.out.println("Enter username: ");
		String username = scanner.next();
		System.out.println("Enter password: ");
		String password = scanner.next();
		
		try {
			String role = HrValidater.validate(username,password);
			
			switch (role) {
			case "recruiter":
				IHRRec recruiter = new HrPortalService();
				recruiter.viewOptionRec();
				switch (scanner.nextInt()) {
				case 1:
					System.out.println(recruiter.addEmp());
					break;
				case 2:
					System.out.println(recruiter.viewEmp());
					break;
				default:
					System.out.println("Wrong Choice !!!");
					break;
				}
				break;
				
			case "manager":
				IHRMan manager = new HrPortalService();
				manager.viewOptionMan();
				switch (scanner.nextInt()) {
				case 1:
					System.out.println(manager.addEmp());
					break;
				case 2:
					System.out.println(manager.viewEmp());
					break;
				case 3:
					System.out.println(manager.editEmp());
					break;
				default:
					System.out.println("Wrong Choice !!!");
					break;
				}
				break;
				
			case "srmanager":
				IHRSrMan srmanager = new HrPortalService();
				srmanager.viewOptionSr();
				switch (scanner.nextInt()) {
				case 1:
					System.out.println(srmanager.addEmp());
					break;
				case 2:
					System.out.println(srmanager.viewEmp());
					break;
				case 3:
					System.out.println(srmanager.editEmp());
					break;
				case 4:
					System.out.println(srmanager.deleteEmp());
					break;
				default:
					System.out.println("Wrong Choice !!!");
					break;
				}
				break;
				
			
			default:
				System.out.println(role);
				break;
			}
		} catch (HrPortalException e) {
			System.out.println(e.getMessage());
		} catch (InputMismatchException e) {
			System.out.println("Invalid Input");
		}
	}

}


