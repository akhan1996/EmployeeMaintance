package com.cg.hrportal.service;

public class HrPortalService implements IHRMan,IHRRec,IHRSrMan{

	@Override
	public String deleteEmp() {
		// TODO Auto-generated method stub
		return "Employee deleted";
	}

	@Override
	public String addEmp() {
		// TODO Auto-generated method stub
		return "Employee Added O_O";
	}

	@Override
	public String viewEmp() {
		// TODO Auto-generated method stub
		return "Employee Viewed";
	}

	@Override
	public String editEmp() {
		// TODO Auto-generated method stub
		return "Employee Edited";
	}
	
	public void viewOptionRec(){
		System.out.println("1. Add Employee");
		System.out.println("2. View Employee");
	}
	
	public void viewOptionMan(){
		viewOptionRec();
		System.out.println("3. Edit Employee");
	}
	public void viewOptionSr(){
		viewOptionMan();
		System.out.println("4. Delete Employee");
	}
}
