package com.cg.hrportal.service;

public interface IHRMan {
	String addEmp();
	String viewEmp();
	String editEmp();
	void viewOptionMan();
}
