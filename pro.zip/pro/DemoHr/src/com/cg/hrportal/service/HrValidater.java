package com.cg.hrportal.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.hrportal.exception.HrExceptionMessages;
import com.cg.hrportal.exception.HrPortalException;

public class HrValidater {

	public static String validate(String user,String pass) throws HrPortalException {
		Pattern uPattern = Pattern.compile("[a-zA-Z0-9]{4,}");
		Pattern pPattern = Pattern.compile(".{2,}");
		Matcher uMatcher = uPattern.matcher(user);
		Matcher pMatcher = uPattern.matcher(pass);
		
		String role = "norole";
		
		if(!uMatcher.matches()){
			throw new HrPortalException(HrExceptionMessages.MESSAGE_1);
		}
		if(!pMatcher.matches()){
			throw new HrPortalException(HrExceptionMessages.MESSAGE_2);
		}
		
		if(user.equals("admin1") && pass.equals("admin1")){
			role = "recruiter";
		}else if(user.equals("admin2") && pass.equals("admin2")){
			role = "manager";
		}else if(user.equals("admin3") && pass.equals("admin3")){
			role = "srmanager";
		}else if(user.equals("admin4") && pass.equals("admin4")){
			role = "employee";
		}else{
			role = "not a valid employee";
		}
		
		return role;
	}
	
	

}
