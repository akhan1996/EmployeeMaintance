package com.cg.hrportal.service;

public interface IHRSrMan {
	String addEmp();
	String viewEmp();
	String editEmp();
	String deleteEmp();
	void viewOptionSr();
}
