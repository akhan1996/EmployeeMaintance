package com.cg.hrportal.exception;

public class HrPortalException extends Exception {

	public HrPortalException() {
		// TODO Auto-generated constructor stub
	}

	public HrPortalException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
