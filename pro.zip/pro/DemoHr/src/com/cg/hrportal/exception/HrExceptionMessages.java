package com.cg.hrportal.exception;

public class HrExceptionMessages {
	
	public static final String MESSAGE_1 = "Invalid username Pattern !!!";
	public static final String MESSAGE_2 = "Invalid password Pattern !!!";
	
	
}
