package com.cg.hrportal.service;

public interface IHRRec {
String addEmp();
String viewEmp();
void viewOptionRec();
}
