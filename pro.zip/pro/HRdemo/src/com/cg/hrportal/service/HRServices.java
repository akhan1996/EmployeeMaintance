package com.cg.hrportal.service;

public class HRServices implements IHRRec,IHRmang,IHRSrmang {

	@Override
	public String delEmp() {
		// TODO Auto-generated method stub
		return "Employee Deleted!";
	}

	@Override
	public String editEmp() {
		// TODO Auto-generated method stub
		return "Employee Edited!";
	}

	@Override
	public String addEmp() {
		// TODO Auto-generated method stub
		return "Employee Added!";
	}

	@Override
	public String viewEmp() {
		// TODO Auto-generated method stub
		return "Employee Viewed!";
	}
	public void viewOptionRec(){
		System.out.println("1. Add Employee");
		System.out.println("2. View Employee");
	}

	public void viewOptionMan(){
		viewOptionRec();
		System.out.println("3. Edit Employee");
	}
	public void viewOptionSr(){
		viewOptionMan();
		System.out.println("4. Delete Employee");
	}

}


