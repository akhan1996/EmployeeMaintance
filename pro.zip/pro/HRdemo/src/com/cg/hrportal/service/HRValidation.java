package com.cg.hrportal.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.hrportal.exception.HRExceptionMsg;
import com.cg.hrportal.exception.HRporatlException;

public class HRValidation {

	public static String validation(String uName, String uPass) throws HRporatlException {
		Pattern pattname = Pattern.compile("[a-zA-Z0-9]{4,}");
		Pattern pattpass = Pattern.compile(".{2,}");
		Matcher umatch = pattname.matcher(uName);
		Matcher pmatch = pattname.matcher(uPass);

		if(!umatch.matches())
		{
			throw new HRporatlException(HRExceptionMsg.Message1);
		}
		if(!pmatch.matches())
		{
			throw new HRporatlException(HRExceptionMsg.Message2);
		}

		String role="abc";
		if(uName.equals("admin1") && uPass.equals("admin1")){
			role = "recruiter";
		}else if(uName.equals("admin2") && uPass.equals("admin2")){
			role = "manager";
		}else if(uName.equals("admin3") && uPass.equals("admin3")){
			role = "srmanager";
		}else{
			role = "not a valid employee";
		}
		return role;
	}

}
