package com.cg.hrportal.service;

public interface IHRSrmang {
	String addEmp();
	String viewEmp();
	String editEmp();
	String delEmp();
	void viewOptionSr();
}
