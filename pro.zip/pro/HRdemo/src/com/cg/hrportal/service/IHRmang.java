package com.cg.hrportal.service;

public interface IHRmang {
	String addEmp();
	String viewEmp();
	String editEmp();
	
	void viewOptionMan();
	
	
}
