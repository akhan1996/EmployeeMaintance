package com.cg.hrportal.exception;

public class HRporatlException extends Exception {

	public HRporatlException() {
		// TODO Auto-generated constructor stub
	}

	public HRporatlException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
