package com.cg.hrportal.exception;

public class HRExceptionMsg {

	public static String Message1="Invalid Username!";
	public static String Message2="Invalid Passowrd!";
}
