package com.cg.hrportal.UI;
import java.util.Scanner;

import com.cg.hrportal.exception.HRporatlException;
import com.cg.hrportal.service.HRServices;
import com.cg.hrportal.service.HRValidation;
import com.cg.hrportal.service.IHRRec;
import com.cg.hrportal.service.IHRSrmang;
import com.cg.hrportal.service.IHRmang;
public class HRPortal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("--Welcome--");
		System.out.println("Enter the Username: ");
		String username = scan.next();
		System.out.println("Enter the Password: ");
		String password = scan.next();
		try{
			String role = HRValidation.validation(username,password);
			switch (role) {
			case "recruiter":
				IHRRec recurit = new HRServices();
				recurit.viewOptionRec();
				switch (scan.nextInt()) {
				case 1:
					System.out.println(recurit.addEmp());

					break;
				case 2:
					System.out.println(recurit.viewEmp());

					break;
				default:System.out.println("Wrong choice!");
				break;
				}
				break;
			case "manager":
				IHRmang manager = new HRServices();
				manager.viewOptionMan();
				switch (scan.nextInt()) {
				case 1:
					System.out.println(manager.addEmp());

					break;
				case 2:
					System.out.println(manager.viewEmp());

					break;
				case 3:
					System.out.println(manager.editEmp());

					break;

				default:System.out.println("Wrong choice!");
				break;
				}
				break;
			case "srmanager":
				IHRSrmang srmanager = new HRServices();
				srmanager.viewOptionSr();
				switch (scan.nextInt()) {
				case 1:
					System.out.println(srmanager.addEmp());

					break;
				case 2:
					System.out.println(srmanager.viewEmp());

					break;
				case 3:
					System.out.println(srmanager.editEmp());

					break;
				case 4:
					System.out.println(srmanager.delEmp());

					break;
				default:System.out.println("Wrong choice!");
				break;
				}
				break;
			default:System.out.println(role);
			break;
			}
		} catch (HRporatlException e) {
			System.out.println(e.getMessage());
			


		}
		scan.close();
	}}
