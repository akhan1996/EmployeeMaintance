package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.EmployeeBean;
import com.cg.entities.UserMasterBean;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	static String name;

	@RequestMapping("about")
	public String aboutPage(){
		return "aboutUs";
	}
	
	@RequestMapping("login")
	public String adminPage(Model model) {
		UserMasterBean user = new UserMasterBean();
		model.addAttribute("user", user);
		return "login";
	}

	@RequestMapping("loginDetails")
	public String validLoginDetails(
			@Valid @ModelAttribute("user") UserMasterBean user,
			BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "login";
		} else {
			try {
				UserMasterBean bean = service.isValid(user.getUserName(),
						user.getPassword());
				String type = bean.getUserType();
				if (type.equals("ADMIN")) {
					name = user.getUserName();
					model.addAttribute("name", name);
					return "adminPage";
				} else if (type.equals("USER")) {

					model.addAttribute("name", user.getUserName());
					return "userPage";
				} else {
					model.addAttribute("msg", "YOU ARE NOT AN ADMIN OR A USER");
					return "login";
				}
			} catch (EmployeeException e) {
				model.addAttribute("msg", e.getMessage());
				return "error";
			}
		}

	}

	@RequestMapping("admin")
	public String adminRedirect(Model model) {
		model.addAttribute("name", name);
		return "adminPage";
	}

	@RequestMapping("add")
	public String toAddEmpoyee(Model model) {

		model.addAttribute("temp", 0);
		EmployeeBean bean = new EmployeeBean();
		model.addAttribute("employee", bean);
		model.addAttribute("grade", new String[] { "M1", "M2", "M3", "M4",
				"M5", "M6", "M7" });
		model.addAttribute("maritalStatus", new String[] { "S", "M", "D", "W" });
		return "addEmployee";
	}

	@RequestMapping("addEmployee")
	public String addEmp(
			@Valid @ModelAttribute("employee") EmployeeBean employee,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("grade", new String[] { "M1", "M2", "M3", "M4",
					"M5", "M6", "M7" });
			model.addAttribute("maritalStatus", new String[] { "S", "M", "D", "W" });
			model.addAttribute("employee", employee);
			model.addAttribute("temp", 0);
			return "addEmployee";
		} else {
			try {
				service.addEmployee(employee);
				model.addAttribute("temp", 1);
				model.addAttribute("id", employee.getEmployeeId());
				return "addEmployee";
			} catch (EmployeeException e) {
				model.addAttribute("msg", e.getMessage());
				return "error";
			}
		}

	}

	@RequestMapping("modify")
	public String modifyPage(Model model) {
		model.addAttribute("temp", 0);
		EmployeeBean bean = new EmployeeBean();
		model.addAttribute("bean", bean);
		return "modifyPage";
	}

	@RequestMapping("modifyDetails")
	public String modifyDetails(@ModelAttribute("bean") EmployeeBean bean,
			Model model) {

		try {
			EmployeeBean employee = service
					.getDetailsById(bean.getEmployeeId());
			model.addAttribute("employee", employee);
			model.addAttribute("temp", 1);
			return "modifyPage";
		} catch (EmployeeException e) {
			model.addAttribute("msg", e.getMessage());
			return "error";
		}
	}

	@RequestMapping("update")
	public String updateDetails(
			@Valid @ModelAttribute("employee") EmployeeBean bean,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("employee", bean);
			model.addAttribute("temp", 1);
			return "modifyPage";
		} else {
			try {
				if (service.modifyEmp(bean)) {
					model.addAttribute("bean", bean);
					return "updatedEmpDetails";
				} else {
					model.addAttribute("msg",
							"COULD NOT UPDATE EMPLOYEE DETAILS");
					return "error";
				}
			} catch (EmployeeException e) {
				model.addAttribute("msg", e.getMessage());
				return "error";
			}
		}
	}

	@RequestMapping("display")
	public String displayEmployeeDetails(Model model) {
		try {
			List<EmployeeBean> list = service.displayAll();
			if (list.isEmpty()) {
				model.addAttribute("msg", "EMPTY LIST");
				return "error";
			} else {
				model.addAttribute("list", list);
				return "displayEmployee";
			}
		} catch (EmployeeException e) {
			model.addAttribute("msg", e.getMessage());
			return "error";
		}

	}

	@RequestMapping("home")
	public String toReturnHome(Model model) {
		return "index";
	}

	@RequestMapping("userPage")
	public String toReturnUserPage(Model model) {
		return "userPage";
	}

	@RequestMapping("search")
	public String toSearch(Model model) {
		return "searchEmployee";
	}

	@RequestMapping("searchEmployee")
	public String toSearchEmp(@RequestParam("search") String name, Model model) {
		EmployeeBean bean = new EmployeeBean();
		model.addAttribute("employee", bean);
		model.addAttribute("name", name);
		model.addAttribute("id", "employeeId");
		model.addAttribute("fname", "firstName");
		model.addAttribute("lname", "lastName");
		model.addAttribute("grade", "grade");
		model.addAttribute("maritalStatus", "maritalStatus");
		model.addAttribute("isFirst", "true");
		return "searchEmployee";

	}

	@RequestMapping("searchEmp")
	public String toSearchEmployee(
			@ModelAttribute("employee") EmployeeBean bean, Model model) {
		try {
			List<EmployeeBean> list = service.search(bean);
			if (list.isEmpty()) {
				String msg = "There are no Employees";
				model.addAttribute("msg", msg);
				return "error";
			}
			model.addAttribute("plist", list);
			return "searchEmp";
		} catch (EmployeeException e) {
			model.addAttribute("msg", "Unable to display list");
			return "error";
		}
	}

}
