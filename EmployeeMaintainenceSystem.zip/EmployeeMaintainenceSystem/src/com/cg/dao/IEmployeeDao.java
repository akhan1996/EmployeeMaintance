package com.cg.dao;

import java.util.List;

import com.cg.entities.EmployeeBean;
import com.cg.entities.UserMasterBean;
import com.cg.exception.EmployeeException;

public interface IEmployeeDao {

	public void addEmployee(EmployeeBean employeebean)
			throws EmployeeException;

	public List<EmployeeBean> displayAll() throws EmployeeException;

	public EmployeeBean getDetailsById(String employeeId)
			throws EmployeeException;

	public UserMasterBean isValid(String user, String pass)
			throws EmployeeException;

	public List<String> getGrades() throws EmployeeException;

	public boolean modifyEmp(EmployeeBean bean) throws EmployeeException;

	public List<EmployeeBean> search(EmployeeBean bean)
			throws EmployeeException;
	
	public String getDeptName(int deptId) throws EmployeeException;
	
	public boolean validDetails(EmployeeBean bean) throws EmployeeException;


}
