package com.cg.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Employee_Table")
public class EmployeeBean {
	
	@Id
	@NotNull(message="Please Enter Employee ID")
	@Pattern(regexp = "^[1-9]{1}[0-9]{5}$", message = "Employee ID must contain only NUMBERS & ShouldNot START with 0")
	@Column(name = "Emp_ID")
	private String employeeId;

	@Pattern(regexp = "^[a-zA-Z]+$", message = "EmployeeFirstName must contain only alphabets")
	@NotEmpty(message="Please Enter First Name")
	@Column(name = "Emp_First_Name")
	private String firstName;
	
	@Pattern(regexp = "^[a-zA-Z]+$", message = "EmployeeLastName must contain only alphabets")
	@NotEmpty(message="Please Enter Last Name")
	@Column(name = "Emp_Last_Name")
	private String lastName;

	@NotNull(message="Please Enter DOB")
	@Column(name = "Emp_Date_of_Birth")
	private Date dateOfBirth;
	
	@NotNull(message="Please Enter DOJ")
	@Column(name = "Emp_Date_of_Joining")
	private Date dateOfJoining;
	
	@Column(name = "Emp_Dept_ID")
	private int departmentId;
	
	@NotEmpty(message="Please Enter Grade")
	@Column(name = "Emp_Grade")
	private String grade;
	
	@Column(name = "Emp_Designation")
	private String designation;
	
	@NotNull
	@Column(name = "Emp_Basic")
	private int salary;
	
	@NotEmpty(message="Please Enter Gender")
	@Column(name = "Emp_Gender")
	private String gender;
	
	@NotEmpty(message="Please Enter Marital Status")
	@Column(name = "Emp_Marital_Status")
	private String maritalStatus;
	
	@Column(name = "Emp_Home_Address")
	private String address;
	
	@Column(name = "Emp_Contact_Num")
	private String phoneNumber;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}