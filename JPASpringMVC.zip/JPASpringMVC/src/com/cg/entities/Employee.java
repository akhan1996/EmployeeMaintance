package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="empid")
	private Long employeeId;
	
	@Column(name="first_name")
	@NotEmpty(message="Enter first name")
	@Pattern(regexp="[a-z]*",message="Only alphabet is allowed!")
	@Size(min=2,max=6,message="Not Valid! btw 2 and 6.")
	private String firstName;
	@Column(name="last_name")
	@NotEmpty(message="Enter last name")
	@Pattern(regexp="[a-z]*",message="Only alphabet is allowed!")
	@Size(min=2,max=6,message="Not Valid! btw 2 and 6.")
	private String lastName;
	@NotEmpty(message="Select Designation")
	private String designation;
	@NotEmpty(message="salary!")
	@Pattern(regexp="[0-9.]*")
	private Double salary;
	
	
	
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	
	
	
	
	
}
