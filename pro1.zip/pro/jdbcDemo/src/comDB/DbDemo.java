package comDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DbDemo {
	public static void main(String[] args) {
		Connection conn=null;
		Statement stmt=null;
		//1.
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn= DriverManager.getConnection("Jdbc:oracle:thin:@localhost:1521:xe","system","root");

			System.out.println(conn);

			stmt=conn.createStatement();

			String query="create table javabatch(id number primary key,name varchar2(10),location varchar2(10))";

			stmt.execute(query);


		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
			//e1.printStackTrace();
		}finally{
			if(stmt!=null){
				try{
					stmt.close();
				}catch(SQLException e){
					System.out.println("Error closing the stmt");
				}
			}
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					System.out.println("Error closing the conn");
				}
			}
		}
		//2.	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver not Loaded");
		}
	}
}
