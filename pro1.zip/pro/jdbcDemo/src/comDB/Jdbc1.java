package comDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Jdbc1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=null;
		 PreparedStatement pstmt=null;
		 ResultSet rs=null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
	 conn=	DriverManager.
			getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "iit", "iit");
		
	   pstmt= conn.prepareStatement("insert into javabatch values(?,?,?)");
	       
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter how many record you want to save in data base");
	   int n=Integer.parseInt(sc.nextLine());
	   
	   conn.setAutoCommit(false);
	   
	   for(int i=0;i<n;i++){
	        System.out.println("Enter Id");
	    	   int id=Integer.parseInt(sc.nextLine());
	    	   System.out.println("Enter name");
		    	   
	    	  String name=sc.nextLine();
	    	  System.out.println("Enter address");
		    	
	    	  String address=sc.nextLine();
	    	  
	    	pstmt.setInt(1, id);
	        pstmt.setString(2,name );
	        pstmt.setString(3, address);
	       // pstmt.setString(4, "");
	    	
	        int count=  pstmt.executeUpdate();
	          conn.commit();   
	       // conn.rollback();
	        
	        
	        System.out.println(count+"Inserted successfully");
	   
	   
	   }
	  
	  
	//select
	   
	   
	   String qury="select * from javabatch";
	   
	   pstmt=conn.prepareStatement(qury);
	   
	   rs= pstmt.executeQuery();
	  
	  while(rs.next()){
		  
		 int col1= rs.getInt(1);
		  String col2=rs.getString(2);
		  String col3=rs.getString(3);
		  //String col4=rs.getString(4);
		  
		  
		  System.out.println(col1+"--"+col2+"--"+col3);
		  
	  }
	  
	  String search="select * from javabatch where name=?";
	  
	  pstmt=conn.prepareStatement(search);
	  System.out.println("Enter the name to search");
	  String g=sc.nextLine();
	  
	  pstmt.setString(1, g);
	  
	 rs= pstmt.executeQuery();
	  System.out.println("the search result is");
	  if(rs.next()==false){
		  
		  System.out.println("No result found");
	  }
	  
	  
	  while(rs.next()){
		  int col1= rs.getInt(1);
		  String col2=rs.getString(2);
		  String col3=rs.getString(3);
		  //String col4=rs.getString(4);
		  
		  
		  System.out.println(col1+"--"+col2+"--"+col3);
		  
		  
		  
	  }
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	   
;	   
	   
	   
	   
	   
	   
	
	
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		try {
			conn.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
		System.out.println("rror while rollback");
		}
			System.out.println(e.getMessage());
			e.printStackTrace();
		}finally{
	      try {
			conn.setAutoCommit(true);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println("Error while commit");
		}

			if(rs!=null){
	            	  
	            	  try {
						rs.close();
					} catch (SQLException e) {
						System.out.println("Error while close the pstmt");
					}
	            	  
	              }	
	        
			
			if(pstmt!=null){
	            	  
	            	  try {
						pstmt.close();
					} catch (SQLException e) {
						System.out.println("Error while close the pstmt");
					}
	            	  
	              }	
	              
	              
	              if(conn!=null){
	            	  
	            	  try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
				
					System.out.println("Error while closing the connction");
					
					}
	            	  
	            	  
	              }
			
			
			
		}
		
		
		
		
	}

}



