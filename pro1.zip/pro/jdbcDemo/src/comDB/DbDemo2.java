package comDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DbDemo2 {

	public static void main(String[] args) {
		PreparedStatement pstmt=null;
		Connection conn=null;
		ResultSet rs=null;
		// TODO Auto-generated method stub
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			 conn= DriverManager.getConnection("Jdbc:oracle:thin:@localhost:1521:xe","system","root");
	
		//getConnection("Jdbc:oracle:thin:@localhost:1521:orcl","system","root");
		 pstmt=conn.prepareStatement("insert into javabatch values(?,?,?)");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetrer number of record");
		int n= Integer.parseInt(sc.nextLine());
		for(int i=0;i<n;i++){
			System.out.println("Enter Id");
			int id =Integer.parseInt(sc.nextLine());
			System.out.println("Enter name");
			String name=sc.nextLine();
			System.out.println("Enter address");
			String add=sc.nextLine();
			
			pstmt.setInt(1,id);
			pstmt.setString(2,name);
			pstmt.setString(3,add);

			   int count=  pstmt.executeUpdate();
		        
		        System.out.println(count+"Inserted successfully");
		   

		}
		String qury="select * from javabatch";
		pstmt=conn.prepareStatement(qury);
		 rs = pstmt.executeQuery();
		
		while(rs.next()){
			int col1 =rs.getInt(1);
			String col2=rs.getString(2);
			String col3=rs.getString(3);
		}
		String search ="select * from javabatch where name=?";
		pstmt=conn.prepareStatement(search);
		
		
		}catch(SQLException e){
			System.out.println(e.getMessage());
			e.printStackTrace();

			}
		finally{
            if(pstmt!=null){
          	  
          	  try {
					pstmt.close();
				} catch (SQLException e) {
					System.out.println("Error while close the pstmt");
				}
          	  
            }	
            
            
            if(conn!=null){
          	  
          	  try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
			
				System.out.println("Error while closing the connction");
				
				}
          	  
          	  
            }
		
		
		
	}
	
}
}	
		


