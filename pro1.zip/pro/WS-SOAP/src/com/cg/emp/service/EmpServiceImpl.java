package com.cg.emp.service;

import javax.jws.WebService;

@WebService(endpointInterface="com.cg.emp.service.IEmpService")
public class EmpServiceImpl {

	public String addEmp(Integer empId,String empName){
		
		return"Hey!! emp id::"+empId+" and name "+empName+" registered successfully!";
	}
	
public String viewEmp(Integer empId){
		
		return"Hey!! Employee details are \n emp id::"+empId+"\n name"+empId+"_name.";
	}
}
