package com.cg.emp.client;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.emp.service.IEmpService;

public class JavaClient {
	
	public static void main(String[] args) throws Exception{
		
		URL url = new URL("http://127.0.0.1:7653/emp?wsdl");
		QName qname = new QName("http://service.emp.cg.com/","EmpServiceImplService");
		Service service =Service.create(url,qname);
		
		IEmpService iEmpService= service.getPort(IEmpService.class);
		String output1= iEmpService.addEmp(2001, "Abcd");
		System.out.println(output1);
		System.out.println("***");
		String output2= iEmpService.viewEmp(2002);
		System.out.println(output2);
		
		
		
	}

}
